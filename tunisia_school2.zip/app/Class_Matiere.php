<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Class_Matiere extends Model
{
    protected $guarded=[''];
}
